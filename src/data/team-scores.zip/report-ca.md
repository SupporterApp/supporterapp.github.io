# 🏆 Classificació d'equips Ffans

_Puntuació diària per equip — fans més actius_

**Actualitzat:** 2026-09-01

| # | Equip | Seguidors | Punts/seguidor | Puntuació total | Taxa activa | Events |
|---|---|---|---|---|---|---|
| 1 | **France** | 28 | 15.32 | 429 | 100% | 3 |
| 2 | **England** | 22 | 15.18 | 334 | 100% | 3 |
| 3 | **Sabadell** | 6 | 8.33 | 50 | 33.3% | 10 |
| 4 | **Marbella** | 3 | 0 | 0 | 0% | 4 |

![Leaderboard chart](./chart-leaderboard.png)

![Supporter growth](./chart-supporters.png)

![Attendance per day](./chart-attendance.png)

---
_Generat automàticament per la pipeline de Score Computation._